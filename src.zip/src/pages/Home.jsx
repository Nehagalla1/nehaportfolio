export default function Home() {
  return (
    <section
      id="home"
      className="min-h-[100vh] flex flex-col md:flex-row justify-center items-center gap-10 px-8 md:px-20 py-20 bg-gray-50"
    >
      {/* Profile Picture */}
      <div className="flex justify-center">
        <img
        src="/image/neha.jpeg"
        alt="Neha Galla"
        className="w-48 h-48 md:w-64 md:h-64 rounded-full border-4 border-blue-500 shadow-lg"
      />

      </div>

      {/* Introduction */}
      <div className="text-center md:text-left max-w-lg">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Hi, I'm Neha Galla</h1>
        <p className="text-lg text-gray-600 mb-6">
          Software Engineer specializing in Java Full Stack Development, Microservices, and Cloud Solutions.
          Passionate about building scalable, high-performance applications.
        </p>

        {/* Buttons */}
        <div className="flex flex-col md:flex-row gap-4 justify-center md:justify-start">
          <a
            href="https://drive.google.com/uc?export=download&id=1x_6qx0aUW9b07x7MMnE77Walv1eDIVRe"
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition"
          >
            Download Resume
          </a>
          <a
            href="https://github.com/Nehagalla1"
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 bg-gray-800 text-white rounded-lg hover:bg-gray-900 transition"
          >
            GitHub
          </a>
          <a
            href="https://www.linkedin.com/in/neha-galla"
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 bg-blue-700 text-white rounded-lg hover:bg-blue-800 transition"
          >
            LinkedIn
          </a>
        </div>
      </div>
    </section>
  );
}

