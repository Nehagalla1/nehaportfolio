export default function About() {
  return (
    <section className="min-h-[70vh] flex flex-col md:flex-row items-center justify-center gap-10 px-6 md:px-20 py-16 bg-gray-50">
      {/* Profile Image */}
      
      {/* About Content */}
      <div className="md:w-2/3 text-center md:text-left">
        <h2 className="text-4xl font-bold mb-4 text-gray-800">About Me</h2>
        <p className="text-lg text-gray-600 leading-relaxed">
          I'm a Software Engineer with 3+ years of experience in building scalable backend systems using Java, Spring Boot, and REST APIs.
          I’ve worked on fintech and healthcare projects, and I'm skilled in database design, API integration, and deploying services on AWS.
        </p>
      </div>
    </section>
  );
}
