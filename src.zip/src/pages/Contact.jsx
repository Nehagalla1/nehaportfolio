export default function Contact() {
  return (
    <section className="min-h-[40vh] px-6 md:px-20 py-16 bg-white text-center">
      <h2 className="text-4xl font-bold mb-10 text-gray-800">Contact Me</h2>
      <p className="text-gray-600 mb-6">
        Interested in working together? Let’s connect!
      </p>

      <div className="max-w-xl mx-auto bg-gray-50 shadow-lg rounded-lg p-8">
        <h3 className="text-xl font-semibold mb-4">Get in Touch</h3>
        <p className="mb-2">
          <strong>Email:</strong>{' '}
          <a href="mailto:gallaneha17@gmail.com" className="text-blue-500 hover:underline">
            gallaneha17@gmail.com
          </a>
        </p>
        <p className="mb-2">
          <strong>LinkedIn:</strong>{' '}
          <a
            href="https://www.linkedin.com/in/neha-galla"
            className="text-blue-500 hover:underline"
            target="_blank"
            rel="noopener noreferrer"
          >
            linkedin.com/in/neha-galla
          </a>
        </p>
        <p>
          <strong>GitHub:</strong>{' '}
          <a
            href="https://github.com/Nehagalla1"
            className="text-blue-500 hover:underline"
            target="_blank"
            rel="noopener noreferrer"
          >
            github.com/Nehagalla1
          </a>
        </p>
      </div>
    </section>
  );
}
