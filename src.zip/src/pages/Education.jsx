export default function Education() {
  return (
    <section className="min-h-[50vh] px-6 md:px-20 py-16 bg-white text-center">
      <h2 className="text-4xl font-bold mb-10 text-gray-800">Education</h2>
      <div className="space-y-6 max-w-2xl mx-auto">
        <div className="bg-gray-50 shadow-lg p-6 rounded-lg">
          <h3 className="text-xl font-semibold">Master's in Computer Science</h3>
          <p className="text-gray-600">University of North Carolina at Charlotte (2022 - 2024)</p>
        </div>
        <div className="bg-gray-50 shadow-lg p-6 rounded-lg">
          <h3 className="text-xl font-semibold">Bachelor's in Computer Science</h3>
          <p className="text-gray-600">Jawaharlal Nehru Technological University (2017 - 2021)</p>
        </div>
      </div>
    </section>
  );
}
