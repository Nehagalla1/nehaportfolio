export default function Experience() {
  const jobs = [
    {
      company: "TekprismIT Inc",
      role: "Software Engineer",
      period: "Sep 2024 – Present",
      details: [
        "Developed Spring Boot microservices for alert management.",
        "Built and consumed REST APIs with external integrations.",
        "Deployed applications on AWS with CI/CD pipelines."
      ]
    },
    {
      company: "Legato Health Technologies",
      role: "Associate Software Engineer",
      period: "Aug 2021 – May 2022",
      details: [
        "Built microservices for health insurance rating engine using Spring Boot.",
        "Integrated SQL and MongoDB for policy and rating data storage.",
        "Collaborated in Agile sprints, handled API testing with Postman."
      ]
    },
    {
     company: "Codinza",
     role:"Project Intern",
     period: "Jan 2019  –  Jan 2021 ",
     details: [
      " Developed projects using Django, SQL, Angular, JavaScript, HTML5, CSS3, PHP, and Bootstrap." ,
      "Worked on MERN stack (MongoDB, Express, React, and NodeJS) for a social media application. ",
      "Integrated the OAuth Authentication framework for authentication using third-party services.",
      "Built Cassandra queries for performing various CRUD operations.",
      "Created methods (get, post, put, delete) to make requests to the API server and tested Restful API using Postman. "
     ]

    }


  ];

  return (
    <section className="min-h-[70vh] px-6 md:px-20 py-16 bg-white">
      <h2 className="text-4xl font-bold mb-10 text-gray-800 text-center">Experience</h2>
      <div className="space-y-8">
        {jobs.map((job, index) => (
          <div key={index} className="bg-gray-50 shadow-lg rounded-lg p-6 hover:shadow-xl transition">
            <h3 className="text-2xl font-semibold">{job.role}</h3>
            <p className="text-gray-600 font-medium">{job.company} • {job.period}</p>
            <ul className="mt-3 list-disc list-inside text-gray-700">
              {job.details.map((d, i) => <li key={i}>{d}</li>)}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}
