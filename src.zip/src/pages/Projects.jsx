const projects = [
  {
    title: "E-Commerce Platform",
    tech: "React, Spring Boot, MySQL",
    link: "https://github.com/Nehagalla1/ecommerce"
  },
  {
    title: "AWS ETL Pipeline",
    tech: "AWS, Python, Redshift",
    link: "https://github.com/Nehagalla1/aws-etl"
  },
  {
    title: "Driver Safety Detection",
    tech: "Python, OpenCV",
    link: "https://github.com/Nehagalla1/driver-safety"
  },
  {
    title: "Neural Body AI",
    tech: "PyTorch, CUDA",
    link: "https://github.com/Nehagalla1/neural-body-ai"
  }
];

export default function Projects() {
  return (
    <section className="min-h-[70vh] px-6 md:px-20 py-16 bg-gray-50 text-center">
      <h2 className="text-4xl font-bold mb-10 text-gray-800">Projects</h2>
      <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        {projects.map((project, index) => (
          <div
            key={index}
            className="bg-white shadow-lg rounded-lg p-6 hover:shadow-xl transition"
          >
            <h3 className="text-xl font-semibold">{project.title}</h3>
            <p className="text-gray-600">{project.tech}</p>
            <a
              href={project.link}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition"
            >
              View Project
            </a>
          </div>
        ))}
      </div>
    </section>
  );
}
