const skills = ["Java", "Spring Boot", "React.js", "Microservices", "SQL", "AWS", "Docker", "Git"];
export default function Skills() {
  return (
    <section className="min-h-[50vh] px-6 md:px-20 py-16 bg-gray-50 text-center">
      <h2 className="text-4xl font-bold mb-10 text-gray-800">Skills</h2>
      <div className="flex flex-wrap justify-center gap-4">
        {skills.map(skill => (
          <span key={skill} className="bg-white shadow-md border px-6 py-3 rounded-lg text-lg hover:bg-blue-100 transition">
            {skill}
          </span>
        ))}
      </div>
    </section>
  );
}
